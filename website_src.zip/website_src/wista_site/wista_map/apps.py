from django.apps import AppConfig


class WistaMapConfig(AppConfig):
    name = 'wista_map'
